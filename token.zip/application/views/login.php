<form method="POST">
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" name="email" placeholder="E-mail" id="email" class="form-control">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" placeholder="Password" id="password" class="form-control">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Login</button>
            </div>
        </div>
    </div>
</form>